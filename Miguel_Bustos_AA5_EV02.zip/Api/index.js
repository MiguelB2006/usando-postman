// Importamos express
const express = require("express");

// Creamos una app de express
const app = express();

// Importamos las rutas que definimos en otro archivo
const authRoutes = require("./routes/authRoutes");

// Usamos JSON para poder trabajar con datos que nos envían
app.use(express.json());

// Usamos las rutas de autenticación
app.use("/api", authRoutes);

// Puerto donde va a correr el servidor
const PORT = 3000;

// Iniciamos el servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
