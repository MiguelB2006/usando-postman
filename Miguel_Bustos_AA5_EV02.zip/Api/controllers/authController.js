// Simulamos una base de datos (solo temporal, se borra al cerrar el servidor)
const users = [];

// Función para registrar usuarios
exports.register = (req, res) => {
  const { username, password } = req.body;

  // Verificamos si ya existe el usuario
  const existingUser = users.find((user) => user.username === username);

  if (existingUser) {
    return res.status(400).json({ message: "El usuario ya existe" });
  }

  // Agregamos el nuevo usuario a nuestra "base de datos"
  users.push({ username, password });

  return res.status(201).json({ message: "Usuario registrado con éxito" });
};

// Función para iniciar sesión
exports.login = (req, res) => {
  const { username, password } = req.body;

  // Buscamos si el usuario existe
  const user = users.find(
    (user) => user.username === username && user.password === password
  );

  if (user) {
    return res.status(200).json({ message: "Autenticación satisfactoria" });
  } else {
    return res
      .status(401)
      .json({ message: "Usuario o contraseña incorrectos" });
  }
};
